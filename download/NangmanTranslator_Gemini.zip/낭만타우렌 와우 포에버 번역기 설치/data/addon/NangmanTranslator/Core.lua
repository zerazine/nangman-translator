local NT = {}
NangmanTr = NT

NT.MEDIA = "Interface\\AddOns\\NangmanTranslator\\media\\"

local function loaded(name)
  if C_AddOns and C_AddOns.IsAddOnLoaded then
    local ok, v = pcall(C_AddOns.IsAddOnLoaded, name)
    if ok and v then return true end
  end
  if IsAddOnLoaded then
    local ok, v = pcall(IsAddOnLoaded, name)
    if ok and v then return true end
  end
  return false
end
NT.inert = loaded("ForeverKit") or (ForeverKitTranslate ~= nil)

function NT.secret(v) return issecretvalue and issecretvalue(v) end

function NT.db()
  NangmanTranslatorDB = NangmanTranslatorDB or {}
  return NangmanTranslatorDB
end
function NT.tr()
  local d = NT.db()
  if type(d.translate) ~= "table" then d.translate = {} end
  return d.translate
end
function NT.trOn()
  local d = NangmanTranslatorDB
  return d and type(d.translate) == "table" and d.translate.on and true or false
end

function NT.say(t) print("|cffe6c066[번역기]|r " .. t) end

do
  local f = CreateFrame("Frame")
  f:RegisterEvent("PLAYER_LOGIN")
  f:SetScript("OnEvent", function()
    if NT.inert then
      print("|cffe6c066[번역기]|r ForeverKit이 켜져 있어서 낭만타우렌 번역기 애드온은 쉬어요 (툴킷 번역 기능을 그대로 씀)")
    end
  end)
end

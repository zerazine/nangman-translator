local NT = NangmanTr
if not NT or NT.inert then return end

local T = {}
NT.T = T
local db = NT.tr
local secret = NT.secret

local function b64(s)
  local out, n = {}, #s
  for i = 1, n, 3 do
    local a, b, c = s:byte(i, i + 2)
    b, c = b or 0, c or 0
    local v = a * 65536 + b * 256 + c
    out[#out + 1] = math.floor(v / 262144) % 64
    out[#out + 1] = math.floor(v / 4096) % 64
    if i + 1 <= n then out[#out + 1] = math.floor(v / 64) % 64 end
    if i + 2 <= n then out[#out + 1] = v % 64 end
  end
  return out
end

local CELLPX = 3
local PAYLOAD = 130
local BYTES = 96
local HEAD = 10
local HOLD = 0.1
local LV = { 0, 40 / 255, 80 / 255, 120 / 255 }
local strip, cells
local seq, lastShow, shownAny = 0, 0, false
local pendBytes = ""

local function layout()
  local _, ph = GetPhysicalScreenSize()
  if not ph or ph <= 0 then ph = 1080 end
  local sz = (768 / ph) * CELLPX
  strip:ClearAllPoints()
  strip:SetPoint("BOTTOMLEFT", nil, "BOTTOMLEFT", 0, 0)
  strip:SetSize(sz * (HEAD + PAYLOAD), sz)
  for i = 1, HEAD + PAYLOAD do
    local t = cells[i]
    if not t then
      t = strip:CreateTexture(nil, "OVERLAY")
      if t.SetSnapToPixelGrid then t:SetSnapToPixelGrid(false) t:SetTexelSnappingBias(0) end
      cells[i] = t
    end
    t:ClearAllPoints()
    t:SetPoint("BOTTOMLEFT", strip, "BOTTOMLEFT", (i - 1) * sz, 0)
    t:SetSize(sz, sz)
  end
end
local function makeStrip()
  if strip then return end
  strip = CreateFrame("Frame", "NangmanTrTranslateStrip", nil)
  strip:SetFrameStrata("TOOLTIP")
  strip:SetFrameLevel(9000)
  strip:SetScale(1)
  strip:EnableMouse(false)
  cells = {}
  layout()
  strip:Hide()
end
local function paint(i, v)
  local t = cells[i]
  t:SetColorTexture(LV[math.floor(v / 16) % 4 + 1], LV[math.floor(v / 4) % 4 + 1], LV[v % 4 + 1], 1)
  t:Show()
end
local function showPacket(vals)
  seq = (seq + 1) % 4096
  for k = 0, 3 do cells[k + 1]:SetColorTexture(LV[k + 1], LV[k + 1], LV[k + 1], 1) cells[k + 1]:Show() end
  local n, sum = #vals, 0
  for i = 1, n do sum = (sum + vals[i] * ((i % 7) + 1)) % 4096 end
  paint(5, math.floor(seq / 64)) paint(6, seq % 64)
  paint(7, math.floor(n / 64)) paint(8, n % 64)
  paint(9, math.floor(sum / 64)) paint(10, sum % 64)
  for i = 1, PAYLOAD do
    if i <= n then paint(HEAD + i, vals[i]) else cells[HEAD + i]:Hide() end
  end
  strip:Show()
end
local function clean(s)
  s = tostring(s or "")
  return (s:gsub("[\t\r\n]", " "))
end
local function recOf(...)
  local n = select("#", ...)
  local parts = {}
  for i = 1, n do parts[i] = clean((select(i, ...))) end
  return table.concat(parts, "\t") .. "\n"
end
local function push(...)
  local rec = recOf(...)
  if #pendBytes > 6000 then return end
  pendBytes = pendBytes .. rec
end
local pendLow = ""
T.push = push
NT.push = push
local function pump(now)
  if now - lastShow < HOLD then return end
  if #pendBytes == 0 and #pendLow > 0 then
    local nl = pendLow:find("\n", 1, true)
    if nl then pendBytes = pendLow:sub(1, nl) pendLow = pendLow:sub(nl + 1) else pendLow = "" end
  end
  if #pendBytes > 0 then
    local take = BYTES
    if #pendBytes < take then take = #pendBytes end
    local chunk
    while take > 1 and take < #pendBytes do
      local nb = pendBytes:byte(take + 1)
      if nb >= 128 and nb < 192 then take = take - 1 else break end
    end
    chunk = pendBytes:sub(1, take)
    pendBytes = pendBytes:sub(take + 1)
    showPacket(b64(chunk))
    lastShow = now
    shownAny = true
  elseif shownAny and now - lastShow > 0.6 then
    strip:Hide()
    shownAny = false
  end
end

local EV = {
  "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_EMOTE",
  "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
  "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER", "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER",
  "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM", "CHAT_MSG_CHANNEL",
}
local function hexOf(r, g, b) return string.format("%02x%02x%02x", math.floor((r or 1) * 255 + 0.5), math.floor((g or 1) * 255 + 0.5), math.floor((b or 1) * 255 + 0.5)) end
NT.hexOf = hexOf
local function classHex(guid)
  if not guid or guid == "" or secret(guid) or not GetPlayerInfoByGUID then return "" end
  local ok, _, cls = pcall(GetPlayerInfoByGUID, guid)
  if not ok or not cls then return "" end
  local c = (CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[cls]) or (RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls])
  if not c then return "" end
  return hexOf(c.r, c.g, c.b)
end
NT.classHex = classHex
local myName = UnitName("player")
local pendLines = {}
local seenIDs = {}
local function playerLineID(t)
  return t:match("|Hplayer:[^:|]*:(%d+):") or t:match("|HBNplayer:[^:]*:[^:|]*:(%d+):")
end
local lineNo = 0
local SID = tostring(math.random(100000, 999999))
local recent = {}
local function remember(f)
  recent[#recent + 1] = { at = GetTime(), f = f }
  while #recent > 30 do table.remove(recent, 1) end
end
local function replay(now)
  if #pendLow > 0 then return end
  for _, r in ipairs(recent) do
    if now - r.at < 600 then
      local f = r.f
      pendLow = pendLow .. recOf(f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10], f[11], SID, "1")
    end
  end
end

local evf = CreateFrame("Frame")
for _, e in ipairs(EV) do pcall(evf.RegisterEvent, evf, e) end
local function onChatEv(_, ev, msg, sender, lang, chanStr, target, flags, zoneId, chanIdx, chanBase, _, lineID, guid, bnID)
  if secret(msg) or secret(sender) then return end
  if lineID and not secret(lineID) then
    local key = ":" .. tostring(lineID) .. ":"
    for i = #pendLines, 1, -1 do if pendLines[i][1]:find(key, 1, true) then table.remove(pendLines, i) end end
    seenIDs[tostring(lineID)] = GetTime()
  end
  local t = ev:sub(10)
  local me = 0
  local mine = UnitName("player") or myName
  if t == "WHISPER_INFORM" or t == "BN_WHISPER_INFORM" then me = 1
  elseif t ~= "WHISPER" and t ~= "BN_WHISPER" and (
    (type(guid) == "string" and not secret(guid) and guid == UnitGUID("player")) or
    (sender and mine and (sender == mine or sender:match("^([^%-]+)") == mine))) then me = 1 end
  local cnum, cname = "", ""
  if t == "CHANNEL" then cnum = tostring(chanIdx or "") cname = tostring(chanBase or chanStr or "") end
  if (t == "BN_WHISPER" or t == "BN_WHISPER_INFORM") and type(bnID) == "number" and not secret(bnID) then
    cnum = tostring(bnID)
    if type(sender) ~= "string" or sender == "" or sender:find("|K", 1, true) then
      local nm
      if C_BattleNet and C_BattleNet.GetAccountInfoByID then
        local ok, info = pcall(C_BattleNet.GetAccountInfoByID, bnID)
        if ok and type(info) == "table" and type(info.battleTag) == "string" then nm = info.battleTag:match("^([^#]+)") end
      end
      if not nm and BNGetFriendInfoByID then
        local ok, _, _, tag = pcall(BNGetFriendInfoByID, bnID)
        if ok and type(tag) == "string" then nm = tag:match("^([^#]+)") end
      end
      if nm and nm ~= "" then sender = nm end
    end
  end
  local col = ChatTypeInfo and ChatTypeInfo[t == "CHANNEL" and ("CHANNEL" .. tostring(chanIdx or "")) or t]
  if not col and ChatTypeInfo then col = ChatTypeInfo[t] end
  lineNo = lineNo + 1
  local f = { "C", t, cnum, cname, sender or "", classHex(guid), col and hexOf(col.r, col.g, col.b) or "ffffff", msg or "", me, 0, lineNo }
  push(f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10], f[11], SID, "0")
  remember(f)
end
local function pkv(...) return select("#", ...), { ... } end
evf:SetScript("OnEvent", function(self, ev, ...)
  local n, args = pkv(...)
  local getF = ChatFrame_GetMessageEventFilters or (ChatFrameUtil and ChatFrameUtil.GetMessageEventFilters)
  local okf, fl = pcall(function() return getF and getF(ev) end)
  if okf and type(fl) == "table" then
    for _, fn in ipairs(fl) do
      local _, r = pkv(pcall(fn, ChatFrame1, ev, unpack(args, 1, n)))
      if r[1] and r[2] then return end
    end
  end
  return onChatEv(self, ev, unpack(args, 1, n))
end)
local function hookCF()
  if not ChatFrame1 or T.hooked then return end
  T.hooked = true
  hooksecurefunc(ChatFrame1, "AddMessage", function(_, text, r, g, b)
    if type(text) ~= "string" or secret(text) then return end
    pendLines[#pendLines + 1] = { text, hexOf(r, g, b) }
  end)
end

local FAKE = {
  { "Testwulf", "WHISPER", "d18f5a", "Hallo! Suchst du noch eine Gruppe für die Höhlen?" },
  { "Emmalyn", "PARTY", "f58cba", "tank can u pull next pack? i need to drink first" },
  { "Pierrot", "WHISPER", "69ccf0", "Salut ! Tu peux m'aider pour cette quête ?" },
  { "Ivanko", "PARTY", "c79c6e", "Привет всем, я танк. Идём в подземелье?" },
  { "Lucía", "WHISPER", "fff569", "¿Tienes hueco en el grupo? Soy sanadora." },
  { "Mirelle", "GUILD", "ff7d0a", "raid tonight 8pm server time, dont be late" },
  { "Kaelthorn", "CHANNEL", "40c7eb", "LF2M SFK need heal and dps, PST" },
  { "Haruka", "WHISPER", "abd473", "こんにちは！一緒にクエストしませんか？" },
}
local fakeAt, fakeI = 0, 0
local function fake(now)
  if not db().test or now < fakeAt then return end
  fakeAt = now + 15
  fakeI = fakeI % #FAKE + 1
  local f = FAKE[fakeI]
  local col = ChatTypeInfo and ChatTypeInfo[f[2] == "CHANNEL" and "CHANNEL4" or f[2]]
  lineNo = lineNo + 1
  push("C", f[2], f[2] == "CHANNEL" and "4" or "", f[2] == "CHANNEL" and "LookingForGroup" or "", f[1], f[3], col and hexOf(col.r, col.g, col.b) or "ffffff", f[4], 0, 1, lineNo, SID, "0")
end

local function chatPanel() return _G.NangmanTrChat end
local lastEdit, lastVis
local function applyHide()
  local p = chatPanel()
  if not p then return end
  local on = db().on
  local eb = ChatFrame1EditBox
  local typing = (eb and eb:HasFocus()) and true or false
  local w = on and 0 or 1
  if on and T.onAt then local age = GetTime() - T.onAt if age < 0.4 then w = 1 elseif age < 0.7 then w = 1 - (age - 0.4) / 0.3 end end
  for _, k in ipairs({ p:GetChildren() }) do
    if k.AddMessage and k.ScrollToBottom and math.abs(k:GetAlpha() - w) > 0.01 then k:SetAlpha(w) end
  end
  if p.chrome then
    if on then
      local cw = typing and 1 or 0
      if T.onAt and GetTime() - T.onAt < 0.7 and not typing then local age = GetTime() - T.onAt cw = (age < 0.4) and 1 or (1 - (age - 0.4) / 0.3) end
      if p.chrome:GetAlpha() ~= cw then p.chrome:SetAlpha(cw) end
      T.chromeForced = true
    elseif T.chromeForced then
      T.chromeForced = nil
      p.chrome:SetAlpha(1)
    end
  end
  if on then
    if typing ~= lastEdit then lastEdit = typing push("E", typing and 1 or 0) end
    local kb = (GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() ~= nil) and true or false
    if kb ~= T.lastKb then T.lastKb = kb push("K", kb and 1 or 0) end
    local vis = p:IsVisible() and true or false
    if vis ~= lastVis then lastVis = vis push("V", vis and 1 or 0) end
  end
end

local function info()
  local name, realm = UnitFullName and UnitFullName("player")
  if not name then name = UnitName("player") end
  if not realm or realm == "" then realm = GetRealmName and GetRealmName() or "" end
  local _, cls = UnitClass("player")
  local c = cls and RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls]
  if db().on then push("P", name or "", realm or "", c and hexOf(c.r, c.g, c.b) or "", db().test and 1 or 0, GetLocale and GetLocale() or "", NT.chatFontSize and NT.chatFontSize() or "")
  else
    local eb = ChatFrame1EditBox
    local ty = ((eb and eb:HasFocus()) or (GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() ~= nil)) and 1 or 0
    push("X", ty, (InCombatLockdown and InCombatLockdown()) and 1 or 0, T.userOff and 1 or 0)
  end
end
local lastChan = ""
local function chans()
  local t, sv = {}, {}
  local L = { GetChannelList() }
  local step = (type(L[3]) == "boolean" or (L[3] == nil and #L >= 3)) and 3 or 2
  for i = 1, #L, step do
    local id, nm = L[i], L[i + 1]
    if type(id) == "number" and type(nm) == "string" then t[#t + 1] = id .. "=" .. nm end
  end
  if EnumerateServerChannels then for _, n in ipairs({ EnumerateServerChannels() }) do if type(n) == "string" then sv[#sv + 1] = n end end end
  local g = table.concat(t, ";") .. "\t" .. table.concat(sv, ";")
  if g ~= lastChan then lastChan = g push("N", table.concat(t, ";"), table.concat(sv, ";")) end
end
NT.chans = function() lastChan = "" pcall(chans) end
do local cf = CreateFrame("Frame") cf:RegisterEvent("CHANNEL_UI_UPDATE") cf:RegisterEvent("PLAYER_ENTERING_WORLD") cf:SetScript("OnEvent", function() C_Timer.After(1, function() pcall(chans) end) end) end
local lastGeo = ""
local function geo()
  local p = chatPanel()
  if not p or not p:GetLeft() then return end
  local _, ph = GetPhysicalScreenSize()
  local s = p:GetEffectiveScale() * ph / 768
  local sh = (UIParent:GetTop() or 768) * UIParent:GetEffectiveScale() * ph / 768
  local L, Tp = p:GetLeft() * s, sh - p:GetTop() * s
  local lk = (NT.chatCfg and NT.chatCfg().locked) and "1" or "0"
  local g = string.format("%d\t%d\t%d\t%d\t%.4f\t%s", math.floor(L + 0.5), math.floor(Tp + 0.5), math.floor(p:GetWidth() * s + 0.5), math.floor(p:GetHeight() * s + 0.5), s, lk)
  if g ~= lastGeo then lastGeo = g push("G", g) end
end

local tick, infoAt = 0, 0
do local pe = CreateFrame("Frame") pe:RegisterEvent("PLAYER_ENTERING_WORLD") pcall(pe.RegisterEvent, pe, "LOADING_SCREEN_DISABLED")
  pe:SetScript("OnEvent", function() infoAt = 0 tick = 2 C_Timer.After(1, function() infoAt = 0 tick = 2 end) end) end
NT.infoNow = function() infoAt = 0 end
NT.feedNow = function() T.lastFeed = nil end
local drv = CreateFrame("Frame")
drv:SetScript("OnUpdate", function(_, el)
  local now = GetTime()
  if #pendLines > 0 then
    for _, l in ipairs(pendLines) do
      local id = playerLineID(l[1])
      if not (id and seenIDs[id]) then push("S", l[2], l[1]) end
    end
    pendLines = {}
    for id, at in pairs(seenIDs) do if now - at > 5 then seenIDs[id] = nil end end
  end
  tick = tick + el
  if tick > 1 then
    tick = 0
    geo()
    if now > infoAt then infoAt = now + 12 lastGeo = "" lastEdit = nil lastVis = nil T.lastFeed = nil T.lastKb = nil info() if (T.chanN or 0) <= 0 then T.chanN = 5 lastChan = "" end T.chanN = T.chanN - 1 pcall(chans) end
    local fg = NT.feedGeo and NT.feedGeo()
    local fon = (NT.feedEnabled and NT.feedEnabled()) and "1" or "0"
    if fg and (fg .. fon) ~= T.lastFeed then
      T.lastFeed = fg .. fon
      local a, b, c, d, e, h, m, z, mv = strsplit("\t", fg)
      push("F", a, b, c, d, e, h, m, z or "13", mv or "0", fon)
    end
  end
  fake(now)
  if now > (T.replayAt or 0) then T.replayAt = now + 30 replay(now) end
  if strip then pump(now) end
  applyHide()
end)

local function look() if NT.btnLook then pcall(NT.btnLook) end end
local function setOn(on)
  local d = db()
  d.on = on and true or false
  if d.on then
    makeStrip() layout() hookCF()
    infoAt = 0 lastGeo = ""
    T.onAt = GetTime()
    NT.say("번역창을 대화창으로 써요 (번역 프로그램이 켜져 있어야 해요)")
    C_Timer.After(1.5, function() if NT.tabsPush then pcall(NT.tabsPush) end end)
  else
    push("X")
    d.test = false
    infoAt = 0
    NT.say("게임 대화창으로 돌아왔어요")
  end
  T.lastFeed = nil
  if NT.feedRefresh then pcall(NT.feedRefresh) end
  look()
end
function NT.setTranslate(on)
  local d = db()
  T.userOff = (not on) and true or nil
  d.userOff = nil
  if (d.on and true or false) ~= (on and true or false) then setOn(on) else infoAt = 0 look() end
end
SLASH_NTTRANSLATE1 = "/nttr"
SLASH_NTTRANSLATE2 = "/번역"
SlashCmdList.NTTRANSLATE = function(arg)
  arg = (arg or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if arg == "테스트" or arg == "test" then
    local d = db()
    if not d.on then NT.setTranslate(true) end
    d.test = not d.test
    fakeAt = GetTime() + 2
    infoAt = 0
    NT.say(d.test and "테스트 모드 켜짐 - 가짜 외국인 대화가 15초마다 와요 · 답장은 내 캐릭에게 귓말로 가요" or "테스트 모드 꺼짐")
    return
  end
  if arg == "켜기" or arg == "on" then NT.setTranslate(true) return end
  if arg == "끄기" or arg == "off" then NT.setTranslate(false) return end
  NT.setTranslate(not db().on)
end

local ld = CreateFrame("Frame")
ld:RegisterEvent("PLAYER_LOGIN")
ld:RegisterEvent("DISPLAY_SIZE_CHANGED")
ld:RegisterEvent("UI_SCALE_CHANGED")
ld:SetScript("OnEvent", function(_, ev)
  myName = UnitName("player")
  if ev == "PLAYER_LOGIN" then
    makeStrip() layout() hookCF()
    do local d = db() d.test = false end
    infoAt = 0
  elseif strip then
    layout()
    lastGeo = ""
    T.lastFeed = nil
  end
end)

do
  local jf = CreateFrame("Frame")
  jf:RegisterEvent("GROUP_JOINED")
  jf:SetScript("OnEvent", function()
    C_Timer.After(0.5, function()
      if not (IsInGroup and IsInGroup()) then return end
      local t = (IsInGroup(LE_PARTY_CATEGORY_INSTANCE or 2) and "INSTANCE_CHAT") or (IsInRaid and IsInRaid() and "RAID") or "PARTY"
      push("J", t)
      local eb = ChatFrame1EditBox
      if eb and not InCombatLockdown() then pcall(eb.SetAttribute, eb, "chatType", t) pcall(eb.SetAttribute, eb, "stickyType", t) end
    end)
  end)
end

do
  local wf = CreateFrame("Frame")
  wf:RegisterEvent("PLAYER_ENTERING_WORLD")
  wf:SetScript("OnEvent", function(_, _, isLogin, isReload)
    if isLogin and not isReload then push("W", UnitName("player") or "") end
  end)
end

do
  local key = CreateFrame("Button", "NangmanTrTranslateKey", UIParent)
  key:Hide()
  key:SetScript("OnClick", function()
    if not db().on then
      NT.setTranslate(true) push("I")
    elseif ChatFrame_OpenChat then
      ChatFrame_OpenChat("")
    end
  end)
  local function bindKey()
    if InCombatLockdown() or not SetOverrideBindingClick then return false end
    SetOverrideBindingClick(key, true, "SHIFT-ENTER", "NangmanTrTranslateKey")
    return true
  end
  function NT.reply(name)
    if type(name) ~= "string" or name == "" or secret(name) then return end
    if db().on then push("R", name)
    elseif ChatFrame_SendTell then ChatFrame_SendTell(name) end
  end
  local w = CreateFrame("Frame")
  w:RegisterEvent("PLAYER_LOGIN") w:RegisterEvent("PLAYER_REGEN_ENABLED")
  local bound = false
  w:SetScript("OnEvent", function()
    if not bound then bound = bindKey() end
  end)
end

SLASH_NTBNTELL1 = "/ntbn"
SlashCmdList.NTBNTELL = function(arg)
  local id, msg = (arg or ""):match("^%s*(%d+)%s+(.+)$")
  id = tonumber(id)
  if id and msg and BNSendWhisper then pcall(BNSendWhisper, id, msg) end
end
SLASH_NTLINK1 = "/ntlink"
SlashCmdList.NTLINK = function(arg)
  arg = (arg or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if not arg:match("^%a+:[%d:%-]+$") then return end
  local text = "[" .. arg .. "]"
  if arg:match("^item:") and GetItemInfo then
    local ok, _, full = pcall(GetItemInfo, arg)
    if ok and type(full) == "string" then text = full end
  end
  if SetItemRef then pcall(SetItemRef, arg, text, "LeftButton") end
end

do
  local links, nid, busy = {}, 0, false
  local typingAt, swallowAt = nil, 0
  local lastLink, lastAt = nil, 0
  local pendLink, pendAt = nil, 0
  local function trTyping() return typingAt and GetTime() - typingAt < 30 end
  local function gameTyping()
    local f = ChatEdit_GetActiveWindow or (ChatFrameUtil and ChatFrameUtil.GetActiveWindow)
    if not f then return false end
    local ok, eb = pcall(f)
    return ok and eb and eb.IsVisible and eb:IsVisible() and true or false
  end
  local function hideSplit() if StackSplitFrame and StackSplitFrame:IsShown() then StackSplitFrame:Hide() end end
  local function send(text)
    nid = nid % 99 + 1
    links[nid] = text
    push("H", nid, text)
    swallowAt = GetTime()
    hideSplit()
  end
  local function onLink(text)
    if type(text) ~= "string" or secret(text) or not text:find("|H", 1, true) then return end
    if gameTyping() then return end
    local now = GetTime()
    if text == lastLink and now - lastAt < 0.1 then return end
    lastLink, lastAt = text, now
    if trTyping() then send(text) else pendLink, pendAt = text, now end
  end
  local function questLink(qid, title, level, idx)
    qid = tonumber(qid)
    if not qid then return nil end
    if GetQuestLink then
      for _, a in ipairs({ qid, idx }) do
        if a then
          local ok, l = pcall(GetQuestLink, a)
          if ok and type(l) == "string" and l:find("|Hquest:" .. qid .. ":", 1, true) then return l end
        end
      end
    end
    if (not title or not level) and idx and GetQuestLogTitle then
      local ok, tt, lv = pcall(GetQuestLogTitle, idx)
      if ok then title = title or tt level = level or lv end
    end
    if not title or title == "" then return nil end
    return string.format("|cffffff00|Hquest:%d:%d|h[%s]|h|r", qid, tonumber(level) or 0, title)
  end
  do
    local function qlIdx(self)
      local off = (FauxScrollFrame_GetOffset and QuestLogListScrollFrame) and FauxScrollFrame_GetOffset(QuestLogListScrollFrame) or 0
      return (self.GetID and self:GetID() or 0) + off
    end
    local function pre(self, button)
      self.__ntW = nil
      if button ~= "LeftButton" or not IsShiftKeyDown() or gameTyping() or not trTyping() or not GetQuestLogTitle then return end
      local idx = qlIdx(self)
      local ok, title, level, _, isHeader, _, _, _, qid = pcall(GetQuestLogTitle, idx)
      if not ok or isHeader or not title or not qid then return end
      self.__ntW = { idx = idx, w = (IsQuestWatched and IsQuestWatched(idx)) and true or false }
      local l = questLink(qid, title, level, idx)
      if l then send(l) end
    end
    local function post(self)
      local w = self.__ntW self.__ntW = nil
      if not w or not IsQuestWatched then return end
      local now = IsQuestWatched(w.idx) and true or false
      if now ~= w.w then
        if w.w then pcall(AddQuestWatch, w.idx) else pcall(RemoveQuestWatch, w.idx) end
        if QuestWatch_Update then pcall(QuestWatch_Update) end
        if QuestLog_Update then pcall(QuestLog_Update) end
      end
    end
    local function hookQL()
      for i = 1, (QUESTS_DISPLAYED or 27) do
        local b = _G["QuestLogTitle" .. i]
        if b and b.HookScript and not b.__ntLink then b.__ntLink = true b:HookScript("PreClick", pre) b:HookScript("PostClick", post) end
      end
    end
    local qe = CreateFrame("Frame")
    qe:RegisterEvent("PLAYER_LOGIN")
    qe:SetScript("OnEvent", function() pcall(hookQL) end)
    if QuestLogFrame and QuestLogFrame.HookScript then QuestLogFrame:HookScript("OnShow", function() pcall(hookQL) end) end
  end
  if HandleModifiedItemClick then hooksecurefunc("HandleModifiedItemClick", function(link) if not IsModifiedClick or IsModifiedClick("CHATLINK") then onLink(link) end end) end
  if ChatEdit_InsertLink then hooksecurefunc("ChatEdit_InsertLink", onLink) end
  if ChatFrameUtil and ChatFrameUtil.InsertLink then hooksecurefunc(ChatFrameUtil, "InsertLink", onLink) end
  if StackSplitFrame then StackSplitFrame:HookScript("OnShow", function(self) if GetTime() - swallowAt < 0.3 then self:Hide() end end) end
  local on = CreateFrame("Button", "NangmanTrTypingOn")
  on:SetScript("OnClick", function()
    typingAt = GetTime()
    if pendLink and GetTime() - pendAt < 0.6 then local t = pendLink pendLink = nil send(t) end
  end)
  local off = CreateFrame("Button", "NangmanTrTypingOff")
  off:SetScript("OnClick", function() typingAt = nil pendLink = nil end)
  local pasted, pastedEb, pastedAt = nil, nil, 0
  local function swap(eb)
    if busy then return end
    local t = eb:GetText()
    if type(t) ~= "string" or secret(t) then return end
    if t == "" then pasted = nil end
    if pasted and pastedEb == eb and GetTime() - pastedAt < 0.6 and not t:find("{fks}", 1, true) then
      if #t > #pasted and t:sub(1, #pasted) == pasted then
        busy = true pcall(eb.SetText, eb, pasted) busy = false
      else
        pasted = t
      end
      return
    end
    if not t:find("{fks}", 1, true) then
      local pre, cmd = t:match("^([^/%s]+)(/nt%a+.*)$")
      if pre and cmd and #pre <= 8 then busy = true pcall(eb.SetText, eb, cmd) busy = false return end
    end
    local nt = t
    local mark = nt:find("{fks}", 1, true)
    if mark then nt = nt:match("{fks}(.*)$") or "" end
    if not nt:find("{fkl", 1, true) and nt == t then return end
    nt = nt:gsub("{fkl(%d+)}", function(i) return links[tonumber(i)] or "" end)
    if nt ~= t then busy = true pcall(eb.SetText, eb, nt) busy = false end
    if mark then
      local now = eb:GetText()
      pasted, pastedEb, pastedAt = (type(now) == "string" and not secret(now)) and now or nt, eb, GetTime()
    end
  end
  local bound, hooked = false, false
  local w = CreateFrame("Frame")
  w:RegisterEvent("PLAYER_LOGIN") w:RegisterEvent("PLAYER_REGEN_ENABLED")
  w:SetScript("OnEvent", function()
    if not hooked then
      hooked = true
      for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local eb = _G["ChatFrame" .. i .. "EditBox"]
        if eb and eb.HookScript then eb:HookScript("OnTextChanged", swap) end
      end
    end
    if not bound and not InCombatLockdown() and SetOverrideBindingClick then
      bound = true
      for _, k in ipairs({ "CTRL-F11", "CTRL-SHIFT-F11" }) do SetOverrideBindingClick(on, true, k, "NangmanTrTypingOn") end
      for _, k in ipairs({ "CTRL-F12", "CTRL-SHIFT-F12" }) do SetOverrideBindingClick(off, true, k, "NangmanTrTypingOff") end
      local nop = CreateFrame("Button", "NangmanTrCtrlV")
      nop:SetScript("OnClick", function()
        if db().on or InCombatLockdown() or not GetCVar then return end
        pcall(SetCVar, "nameplateShowAll", GetCVar("nameplateShowAll") == "1" and "0" or "1")
      end)
      SetOverrideBindingClick(nop, true, "CTRL-V", "NangmanTrCtrlV")
    end
  end)
end

do
  local qf = CreateFrame("Frame")
  qf:RegisterEvent("PLAYER_REGEN_DISABLED") qf:RegisterEvent("PLAYER_REGEN_ENABLED") qf:RegisterEvent("PLAYER_ENTERING_WORLD")
  qf:SetScript("OnEvent", function(_, e)
    local on = (e == "PLAYER_REGEN_DISABLED") or (e == "PLAYER_ENTERING_WORLD" and InCombatLockdown and InCombatLockdown())
    push("Q", on and 1 or 0)
  end)
end

do
  local pf, last, acc = CreateFrame("Frame"), nil, 0
  pf:SetScript("OnUpdate", function(_, el)
    acc = acc + el if acc < 0.1 then return end acc = 0
    local on = false
    for i = 1, 4 do local p = _G["StaticPopup" .. i] if p and p:IsShown() then on = true break end end
    if on ~= last then last = on push("U", on and 1 or 0) end
  end)
end
